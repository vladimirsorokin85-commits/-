import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import mix_stream  # noqa: E402
import build_video  # noqa: E402


class ScriptParserTests(unittest.TestCase):
    def test_parse_two_scenes(self):
        with tempfile.TemporaryDirectory() as folder:
            script = Path(folder) / "script.md"
            script.write_text(
                "### [s01e01_a01] [voice-00] [ГУДЕНИЕ] Запись первая\n"
                "Доброй ночи, друзья.\n\n"
                "### [s01e01_a02] [voice-01] [ИНТЕРКОМ] Поправка кота\n"
                "Не совсем так, Бульк.\n",
                encoding="utf-8",
            )
            scenes = mix_stream.parse_script(script)
        self.assertEqual([scene.scene_id for scene in scenes], ["s01e01_a01", "s01e01_a02"])
        self.assertEqual(scenes[1].voice, "voice-01")
        self.assertEqual(scenes[0].text, "Доброй ночи, друзья.")

    def test_spoken_text_linter_rejects_digits_and_latin(self):
        with tempfile.TemporaryDirectory() as folder:
            script = Path(folder) / "script.md"
            script.write_text(
                "### [s01e01_a01] [voice-00] [ГУДЕНИЕ] Заголовок\n"
                "Встречаемся в 2026 году.\n",
                encoding="utf-8",
            )
            with self.assertRaises(mix_stream.BuildError):
                mix_stream.parse_script(script)

    def test_spoken_text_linter_can_be_disabled(self):
        with tempfile.TemporaryDirectory() as folder:
            script = Path(folder) / "script.md"
            script.write_text(
                "### [s01e01_a01] [voice-00] [ГУДЕНИЕ] Заголовок\n"
                "Это тестовая реплика номер 1.\n",
                encoding="utf-8",
            )
            self.assertEqual(len(mix_stream.parse_script(script, lint=False)), 1)


class TimingTests(unittest.TestCase):
    def test_frame_distribution_is_exact(self):
        frames = build_video.distribute_frames(2400, 37)
        self.assertEqual(sum(frames), 2400)
        self.assertLessEqual(max(frames) - min(frames), 1)

    def test_timeline_stays_in_requested_sleep_length(self):
        scenes = [
            mix_stream.Scene(
                scene_id=f"s01e01_a{i:02d}", voice="voice-00", tag="", title="",
                text="текст", duration=78.0,
            )
            for i in range(1, 25)
        ]
        timeline, target, gap = mix_stream.build_timeline(
            scenes, target=None, intro=6, outro=12, min_gap=3, max_gap=20,
        )
        self.assertGreaterEqual(target, 1800)
        self.assertLessEqual(target, 2400)
        self.assertGreaterEqual(gap, 3)
        self.assertLessEqual(gap, 20)
        self.assertEqual(len(timeline), 24)

    def test_natural_long_episode_can_exceed_forty_minutes(self):
        scenes = [
            mix_stream.Scene(
                scene_id=f"s01e01_a{i:02d}", voice="voice-00", tag="", title="",
                text="текст", duration=120.0,
            )
            for i in range(1, 23)
        ]
        timeline, target, gap = mix_stream.build_timeline(
            scenes, target=None, intro=6, outro=12, min_gap=3, max_gap=20,
        )
        self.assertGreater(target, 2400)
        self.assertLessEqual(target, 3600)
        self.assertGreaterEqual(gap, 3)
        self.assertLessEqual(gap, 20)
        self.assertEqual(len(timeline), 22)


if __name__ == "__main__":
    unittest.main()
