# Дополнение к архиву v0.9 — рилсы и YouTube

В архив включён соцпак пилота:

- `social/reels/reel_01_key_without_door.mp4` — вертикальный тизер (9:16, около 37,5 с).
- `social/reels/reel_02_cosmic_bureaucracy.mp4` — второй вертикальный тизер (9:16, около 37,3 с).
- `social/reels/*.srt` — внешние субтитры; `*.ass` — стилизация вшитых субтитров.
- `social/YOUTUBE_DESCRIPTION.txt` — готовое описание для вставки в YouTube.
- `social/YOUTUBE_DESCRIPTION.md` — название, описание, главы, закреплённый комментарий и теги.
- `social/social_pack_v1_0.zip` — отдельный компактный архив соцматериалов.

Подробности и пересборка: `social/README.md`, `social/build_social.py`.
